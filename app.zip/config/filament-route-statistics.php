<?php

return [

    'sort' => [
        'column' => 'id',
        'direction' => 'desc',
    ],
    'username' => [
        'column' => 'email'
    ]
];
