<div>Number: {{ $record->id }}</div>
<div>Nombor Klien: {{ $record->registrar_id }}</div>