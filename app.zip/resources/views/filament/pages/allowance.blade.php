<x-filament-panels::page>
@livewire('list-allowance')
</x-filament-panels::page>
