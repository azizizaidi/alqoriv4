<x-filament-panels::page>
@livewire('invoice-view')


</x-filament-panels::page>
