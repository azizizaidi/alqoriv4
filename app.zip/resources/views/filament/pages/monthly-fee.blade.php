<x-filament-panels::page>
@livewire('list-monthly-fee')


</x-filament-panels::page>
