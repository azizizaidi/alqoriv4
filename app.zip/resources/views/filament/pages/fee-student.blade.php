<x-filament-panels::page>
@livewire('list-fee')


</x-filament-panels::page>
