
<div>
    {{ $this->table }}
</div>

