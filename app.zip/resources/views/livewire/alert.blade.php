<div>
    @if ($message)
        <div class="alert alert-{{ $type }}">
            {{ $message }}
        </div>
    @endif
</div>
