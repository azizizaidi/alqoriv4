<div>
    {{ $this->table }}
</div>

