<div>
    {{ $this->table }}


    @if($alertMessage)
        <div class="alert alert-{{ $alertType }}">
            {{ $alertMessage }}
        </div>
    @endif
</div>