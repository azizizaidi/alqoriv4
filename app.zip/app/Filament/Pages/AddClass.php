<?php

namespace App\Filament\Pages;

use Filament\Pages\Page;

class AddClass extends Page
{
    protected static ?string $navigationIcon = 'fluentui-book-add-24-o';

    protected static string $view = 'filament.pages.add-class';

    public static function table(Table $table): Table
    {
        return $table
    
            ->emptyStateIcon('heroicon-o-bookmark');
    
    }
    
    public static function getNavigationLabel(): string
    {
        return __('Tambah Kelas');
    }
    
    public function getHeading(): string
    {
        return __('Tambah Kelas');
    }

    
}
