<?php

namespace App\Filament\Resources\AssignClassTeacherResource\Pages;

use App\Filament\Resources\AssignClassTeacherResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreateAssignClassTeacher extends CreateRecord
{
    protected static string $resource = AssignClassTeacherResource::class;
}
