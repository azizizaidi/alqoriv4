<?php

namespace App\Filament\Resources\FeeRateResource\Pages;

use App\Filament\Resources\FeeRateResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreateFeeRate extends CreateRecord
{
    protected static string $resource = FeeRateResource::class;
}
