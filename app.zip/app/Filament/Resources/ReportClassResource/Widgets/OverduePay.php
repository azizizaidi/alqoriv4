<?php

namespace App\Filament\Resources\ReportClassResource\Widgets;

use Filament\Widgets\StatsOverviewWidget as BaseWidget;
use Filament\Widgets\StatsOverviewWidget\Stat;

class OverduePay extends BaseWidget
{
    protected function getStats(): array
    {
        return [
            //
        ];
    }
}
