<?php

namespace App\Livewire;

use App\Models\ReportClass;
use Filament\Tables\Grouping\Group;
use Filament\Tables\Columns\Summarizers\Sum;
use Filament\Forms\Concerns\InteractsWithForms;
use Filament\Forms\Contracts\HasForms;
use Filament\Tables\Columns\TextColumn;
use Filament\Tables\Concerns\InteractsWithTable;
use Filament\Tables\Contracts\HasTable;
use Filament\Tables\Table;
use Illuminate\Contracts\View\View;
use Filament\Tables\Actions\Action;
use Filament\Tables\Actions\BulkAction;
use Filament\Tables\Actions\BulkActionGroup;
use Filament\Tables\Actions\DeleteBulkAction;
use Livewire\Component;
use Barryvdh\DomPDF\Facade\Pdf;
use Illuminate\Support\Facades\Blade;
use pxlrbt\FilamentExcel\Actions\Tables\ExportBulkAction;
use pxlrbt\FilamentExcel\Columns\Column;
use pxlrbt\FilamentExcel\Exports\ExcelExport;
use pxlrbt\FilamentExcel\Actions\Pages\ExportAction;
use Illuminate\Database\Eloquent\Collection;
use Filament\Tables\Columns\SelectColumn;
use Filament\Tables\Columns\IconColumn;
use Awcodes\FilamentBadgeableColumn\Components\Badge;
use Awcodes\FilamentBadgeableColumn\Components\BadgeableColumn;
use Filament\Tables\Columns\ColorColumn;
use Filament\Support\Enums\FontWeight;
use Filament\Tables\Columns\Layout\Split;
use Filament\Tables\Columns\Layout\Stack;
use Filament\Tables\Columns\ImageColumn;
use Filament\Tables\Columns\Layout\Grid;
use Filament\Tables\Filters\Filter;
use Filament\Tables\Filters\SelectFilter;
use Filament\Tables\Filters\TernaryFilter;
use Filament\Forms\Components\Select;
use Filament\Forms\Components\FileUpload;
use Filament\Forms\Components\TextInput;
use Filament\Tables\Columns\BadgeColumn;
use Illuminate\Database\Eloquent\Model;
use Filament\Forms\Form;
use Illuminate\Database\Eloquent\Builder;





class ListAllowance extends Component implements HasForms, HasTable
{
    use InteractsWithTable;
    use InteractsWithForms;



    public function table(Table $table): Table



    {

        return $table

       
            ->striped()
            
            ->groups([
                    Group::make('month')
                    ->orderQueryUsing(fn (Builder $query, string $direction) => $query->orderBy('created_by_id', $direction)),
                    Group::make('created_by.name')
                    ->orderQueryUsing(fn (Builder $query, string $direction) => $query->orderBy('created_by_id', $direction)),
                   // ->collapsible(),
                   // ->scopeQueryByKeyUsing(fn (Builder $query, string $key) => $query->where('month', $key)),
                   // ->groupQueryUsing(fn (Builder $query) => $query->groupBy('month')),
                ])  
             ->groupRecordsTriggerAction(
                    fn (Action $action) => $action
                        ->button()
                        ->label('Group records'),
                )
            ->query(ReportClass::query())
            ->paginated([5,10, 25, 50, 100])
            ->deferLoading()
            ->columns([

                    //TextColumn::make('id')
                   // ->searchable(isIndividual: true),

                    TextColumn::make('created_by.id')
                    ->label('ID Guru')
                    ->sortable(),
                    TextColumn::make('created_by.name')
                    ->label('Nama Guru')
                    //->toggleable(isToggledHiddenByDefault: true)
                    ->searchable(),

               
                    TextColumn::make('month')
                    ->label('Bulan')
                    ->toggleable()
                    ->searchable(),

                    TextColumn::make('allowance')
                    ->label('Elaun')
                    ->currency('MYR')
                    ->summarize(Sum::make()->money('MYR'))
                    ->toggleable(),
                  
                    IconColumn::make('allowance_note')
                
                    ->icon(fn (string $state): string => match ($state) {
                        'dah_bayar' => 'heroicon-o-check-circle',
                        'belum_bayar' => 'forkawesome-times',
                        'NULL' => 'heroicon-o-check-circle', // Show 'heroicon-o-check-circle' icon for null state
                    })
                    ->color(fn (string $state): string => match ($state) {
                        'dah_bayar' => 'success',
                        'belum_bayar' => 'danger',
                       
                        default => 'gray',
                    })
                    ->label('Status'),



            ])
            ->defaultGroup('created_by.name')
            //->groupsOnly()
    
            ->filters([
                SelectFilter::make('month')
                ->label('Bulan')
                ->searchable()
                ->preload()
               // ->default()
                ->options([
                    '03-2022' => 'Mac 2022',
                    '04-2022' => 'April 2022',
                    '05-2022' => 'Mei 2022',
                    '06-2022' => 'Jun 2022',
                    '07-2022' => 'Julai 2022',
                    '08-2022' => 'Ogos 2022',
                    '09-2022' => 'September 2022',
                    '10-2022' => 'Oktober 2022',
                    '11-2022' => 'November 2022',
                    '12-2022' => 'Disember 2022',
                    '01-2023' => 'Januari 2023',
                    '02-2023' => 'Februari 2023',
                    '03-2023' => 'Mac 2023',
                    '04-2023' => 'April 2023',
                    '05-2023' => 'Mei 2023',
                    '06-2023' => 'Jun 2023',
                    '07-2023' => 'Julai 2023',
                    '08-2023' => 'Ogos 2023',
                    '09-2023' => 'September 2023',
                    '10-2023' => 'Oktober 2023',
                    '11-2023' => 'November 2023',
                    '12-2023' => 'Disember 2023',
                    '01-2024' => 'Januari 2024',
                    '02-2024' => 'Februari 2024',
                    '03-2024' => 'Mac 2024',
                    '04-2024' => 'April 2024',
                ]),
             

            ])
            ->actions([
           
            ])
            ->groupedBulkActions([

                    ExportBulkAction::make()
                    ->label('Eksport'),
                    //Tables\Actions\DeleteBulkAction::make(),
                    BulkAction::make('delete')
                    ->requiresConfirmation()
                    ->label('Padam')
                    ->action(fn (Collection $records) => $records->each->delete())
                    ->icon('heroicon-s-trash'),
       
                    BulkAction::make('edit')
                    ->icon('heroicon-o-pencil')
                    ->label('Ubah')
                    ->modalSubheading()
                    ->action(function (array $data, Collection $records): void {
                        // Handle bulk edit action
                        foreach ($records as $record) {
                            $record->allowance_note = $data['allowance_note']; // Assign the value to the property
                            $record->save();
                        }
                    })
                    ->fillForm(function (Collection $records): array {
                        // Map each selected record to its 'allowance_note' value
                        $formData = [];
                        foreach ($records as $record) {
                            $formData[$record->id] = [
                                'allowance_note' => $record->allowance_note,
                            ];
                        }
                        return $formData;
                    })
                    ->form([
                   
                         Select::make('allowance_note')
                            ->label('Status')
                            ->options([
                                'dah_bayar' => 'Elaun Dah Dibayar',
                                'belum_bayar' => 'Elaun Belum Dibayar',
                            ])
                            ->required(),
                    ])


            ]);
    }

    public function render(): View
    {
        return view('livewire.list-fee');
    }

    

}
