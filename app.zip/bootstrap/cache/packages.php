<?php return array (
  'afatmustafa/blade-hugeicons' => 
  array (
    'providers' => 
    array (
      0 => 'Afatmustafa\\HugeIcons\\BladeHugeIconsServiceProvider',
    ),
  ),
  'akaunting/laravel-money' => 
  array (
    'providers' => 
    array (
      0 => 'Akaunting\\Money\\Provider',
    ),
  ),
  'althinect/filament-spatie-roles-permissions' => 
  array (
    'providers' => 
    array (
      0 => 'Althinect\\FilamentSpatieRolesPermissions\\FilamentSpatieRolesPermissionsServiceProvider',
    ),
    'aliases' => 
    array (
      'FilamentSpatieRolesPermissions' => 'Althinect\\FilamentSpatieRolesPermissions\\FilamentSpatieRolesPermissionsFacade',
    ),
  ),
  'amendozaaguiar/filament-route-statistics' => 
  array (
    'providers' => 
    array (
      0 => 'Amendozaaguiar\\FilamentRouteStatistics\\FilamentRouteStatisticsServiceProvider',
    ),
  ),
  'andreiio/blade-iconoir' => 
  array (
    'providers' => 
    array (
      0 => 'AndreiIonita\\BladeIconoir\\BladeIconoirServiceProvider',
    ),
  ),
  'andreiio/blade-remix-icon' => 
  array (
    'providers' => 
    array (
      0 => 'AndreiIonita\\BladeRemixIcon\\BladeRemixIconServiceProvider',
    ),
  ),
  'anourvalar/eloquent-serialize' => 
  array (
    'aliases' => 
    array (
      'EloquentSerialize' => 'AnourValar\\EloquentSerialize\\Facades\\EloquentSerializeFacade',
    ),
  ),
  'ariaieboy/filament-currency' => 
  array (
    'providers' => 
    array (
      0 => 'Ariaieboy\\FilamentCurrency\\FilamentCurrencyServiceProvider',
    ),
    'aliases' => 
    array (
      'FilamentCurrency' => 'Ariaieboy\\FilamentCurrency\\Facades\\FilamentCurrency',
    ),
  ),
  'awcodes/filament-badgeable-column' => 
  array (
    'providers' => 
    array (
      0 => 'Awcodes\\FilamentBadgeableColumn\\BadgeableColumnServiceProvider',
    ),
  ),
  'awcodes/filament-versions' => 
  array (
    'providers' => 
    array (
      0 => 'Awcodes\\FilamentVersions\\FilamentVersionsServiceProvider',
    ),
  ),
  'aymanalhattami/filament-slim-scrollbar' => 
  array (
    'providers' => 
    array (
      0 => 'Aymanalhattami\\FilamentSlimScrollbar\\FilamentSlimScrollbarServiceProvider',
    ),
    'aliases' => 
    array (
      'FilamentSlimScrollbar' => 'Aymanalhattami\\FilamentSlimScrollbar\\FilamentSlimScrollbarFacade',
    ),
  ),
  'barryvdh/laravel-debugbar' => 
  array (
    'providers' => 
    array (
      0 => 'Barryvdh\\Debugbar\\ServiceProvider',
    ),
    'aliases' => 
    array (
      'Debugbar' => 'Barryvdh\\Debugbar\\Facades\\Debugbar',
    ),
  ),
  'barryvdh/laravel-dompdf' => 
  array (
    'providers' => 
    array (
      0 => 'Barryvdh\\DomPDF\\ServiceProvider',
    ),
    'aliases' => 
    array (
      'Pdf' => 'Barryvdh\\DomPDF\\Facade\\Pdf',
      'PDF' => 'Barryvdh\\DomPDF\\Facade\\Pdf',
    ),
  ),
  'bilfeldt/laravel-request-logger' => 
  array (
    'providers' => 
    array (
      0 => 'Bilfeldt\\RequestLogger\\RequestLoggerServiceProvider',
    ),
    'aliases' => 
    array (
      'RequestLogger' => 'Bilfeldt\\RequestLogger\\RequestLoggerFacade',
    ),
  ),
  'bilfeldt/laravel-route-statistics' => 
  array (
    'providers' => 
    array (
      0 => 'Bilfeldt\\LaravelRouteStatistics\\LaravelRouteStatisticsServiceProvider',
    ),
  ),
  'blade-ui-kit/blade-heroicons' => 
  array (
    'providers' => 
    array (
      0 => 'BladeUI\\Heroicons\\BladeHeroiconsServiceProvider',
    ),
  ),
  'blade-ui-kit/blade-icons' => 
  array (
    'providers' => 
    array (
      0 => 'BladeUI\\Icons\\BladeIconsServiceProvider',
    ),
  ),
  'codeat3/blade-eos-icons' => 
  array (
    'providers' => 
    array (
      0 => 'Codeat3\\BladeEosIcons\\BladeEosIconsServiceProvider',
    ),
  ),
  'codeat3/blade-fluentui-system-icons' => 
  array (
    'providers' => 
    array (
      0 => 'Codeat3\\BladeFluentUiSystemIcons\\BladeFluentUiSystemIconsServiceProvider',
    ),
  ),
  'codeat3/blade-forkawesome' => 
  array (
    'providers' => 
    array (
      0 => 'Codeat3\\BladeForkAwesome\\BladeForkAwesomeServiceProvider',
    ),
  ),
  'codeat3/blade-google-material-design-icons' => 
  array (
    'providers' => 
    array (
      0 => 'Codeat3\\BladeGoogleMaterialDesignIcons\\BladeGoogleMaterialDesignIconsServiceProvider',
    ),
  ),
  'codeat3/blade-iconpark' => 
  array (
    'providers' => 
    array (
      0 => 'Codeat3\\BladeIconpark\\BladeIconparkServiceProvider',
    ),
  ),
  'codeat3/blade-phosphor-icons' => 
  array (
    'providers' => 
    array (
      0 => 'Codeat3\\BladePhosphorIcons\\BladePhosphorIconsServiceProvider',
    ),
  ),
  'coolsam/flatpickr' => 
  array (
    'providers' => 
    array (
      0 => 'Coolsam\\FilamentFlatpickr\\FilamentFlatpickrServiceProvider',
    ),
    'aliases' => 
    array (
      'FilamentFlatpickr' => 'Coolsam\\FilamentFlatpickr\\Facades\\FilamentFlatpickr',
    ),
  ),
  'filament/actions' => 
  array (
    'providers' => 
    array (
      0 => 'Filament\\Actions\\ActionsServiceProvider',
    ),
  ),
  'filament/filament' => 
  array (
    'providers' => 
    array (
      0 => 'Filament\\FilamentServiceProvider',
    ),
  ),
  'filament/forms' => 
  array (
    'providers' => 
    array (
      0 => 'Filament\\Forms\\FormsServiceProvider',
    ),
  ),
  'filament/infolists' => 
  array (
    'providers' => 
    array (
      0 => 'Filament\\Infolists\\InfolistsServiceProvider',
    ),
  ),
  'filament/notifications' => 
  array (
    'providers' => 
    array (
      0 => 'Filament\\Notifications\\NotificationsServiceProvider',
    ),
  ),
  'filament/spatie-laravel-settings-plugin' => 
  array (
    'providers' => 
    array (
      0 => 'Filament\\SpatieLaravelSettingsPluginServiceProvider',
    ),
  ),
  'filament/support' => 
  array (
    'providers' => 
    array (
      0 => 'Filament\\Support\\SupportServiceProvider',
    ),
  ),
  'filament/tables' => 
  array (
    'providers' => 
    array (
      0 => 'Filament\\Tables\\TablesServiceProvider',
    ),
  ),
  'filament/widgets' => 
  array (
    'providers' => 
    array (
      0 => 'Filament\\Widgets\\WidgetsServiceProvider',
    ),
  ),
  'hasnayeen/themes' => 
  array (
    'providers' => 
    array (
      0 => 'Hasnayeen\\Themes\\ThemesServiceProvider',
    ),
  ),
  'jantinnerezo/livewire-alert' => 
  array (
    'providers' => 
    array (
      0 => 'Jantinnerezo\\LivewireAlert\\LivewireAlertServiceProvider',
    ),
    'aliases' => 
    array (
      'LivewireAlert' => 'Jantinnerezo\\LivewireAlert\\LivewireAlertFacade',
    ),
  ),
  'joaopaulolndev/filament-pdf-viewer' => 
  array (
    'providers' => 
    array (
      0 => 'Joaopaulolndev\\FilamentPdfViewer\\FilamentPdfViewerServiceProvider',
    ),
    'aliases' => 
    array (
      'FilamentPdfViewer' => 'Joaopaulolndev\\FilamentPdfViewer\\Facades\\FilamentPdfViewer',
    ),
  ),
  'kenepa/multi-widget' => 
  array (
    'providers' => 
    array (
      0 => 'Kenepa\\MultiWidget\\MultiWidgetServiceProvider',
    ),
  ),
  'kirschbaum-development/eloquent-power-joins' => 
  array (
    'providers' => 
    array (
      0 => 'Kirschbaum\\PowerJoins\\PowerJoinsServiceProvider',
    ),
  ),
  'lab404/laravel-impersonate' => 
  array (
    'providers' => 
    array (
      0 => 'Lab404\\Impersonate\\ImpersonateServiceProvider',
    ),
  ),
  'laravel/sail' => 
  array (
    'providers' => 
    array (
      0 => 'Laravel\\Sail\\SailServiceProvider',
    ),
  ),
  'laravel/sanctum' => 
  array (
    'providers' => 
    array (
      0 => 'Laravel\\Sanctum\\SanctumServiceProvider',
    ),
  ),
  'laravel/tinker' => 
  array (
    'providers' => 
    array (
      0 => 'Laravel\\Tinker\\TinkerServiceProvider',
    ),
  ),
  'livewire/livewire' => 
  array (
    'providers' => 
    array (
      0 => 'Livewire\\LivewireServiceProvider',
    ),
    'aliases' => 
    array (
      'Livewire' => 'Livewire\\Livewire',
    ),
  ),
  'maatwebsite/excel' => 
  array (
    'providers' => 
    array (
      0 => 'Maatwebsite\\Excel\\ExcelServiceProvider',
    ),
    'aliases' => 
    array (
      'Excel' => 'Maatwebsite\\Excel\\Facades\\Excel',
    ),
  ),
  'miguilim/filament-auto-panel' => 
  array (
    'providers' => 
    array (
      0 => 'Miguilim\\FilamentAutoPanel\\FilamentAutoPanelProvider',
    ),
  ),
  'nesbot/carbon' => 
  array (
    'providers' => 
    array (
      0 => 'Carbon\\Laravel\\ServiceProvider',
    ),
  ),
  'nunomaduro/collision' => 
  array (
    'providers' => 
    array (
      0 => 'NunoMaduro\\Collision\\Adapters\\Laravel\\CollisionServiceProvider',
    ),
  ),
  'nunomaduro/termwind' => 
  array (
    'providers' => 
    array (
      0 => 'Termwind\\Laravel\\TermwindServiceProvider',
    ),
  ),
  'postare/blade-mdi' => 
  array (
    'providers' => 
    array (
      0 => 'Postare\\BladeMdi\\BladeMdiServiceProvider',
    ),
  ),
  'pxlrbt/filament-excel' => 
  array (
    'providers' => 
    array (
      0 => 'pxlrbt\\FilamentExcel\\FilamentExcelServiceProvider',
    ),
  ),
  'ryangjchandler/blade-capture-directive' => 
  array (
    'providers' => 
    array (
      0 => 'RyanChandler\\BladeCaptureDirective\\BladeCaptureDirectiveServiceProvider',
    ),
    'aliases' => 
    array (
      'BladeCaptureDirective' => 'RyanChandler\\BladeCaptureDirective\\Facades\\BladeCaptureDirective',
    ),
  ),
  'saade/filament-laravel-log' => 
  array (
    'providers' => 
    array (
      0 => 'Saade\\FilamentLaravelLog\\FilamentLaravelLogServiceProvider',
    ),
    'aliases' => 
    array (
      'FilamentLaravelLog' => 'Saade\\FilamentLaravelLog\\Facades\\FilamentLaravelLog',
    ),
  ),
  'shuvroroy/filament-spatie-laravel-health' => 
  array (
    'providers' => 
    array (
      0 => 'ShuvroRoy\\FilamentSpatieLaravelHealth\\FilamentSpatieLaravelHealthServiceProvider',
    ),
  ),
  'spatie/laravel-health' => 
  array (
    'providers' => 
    array (
      0 => 'Spatie\\Health\\HealthServiceProvider',
    ),
    'aliases' => 
    array (
      'Health' => 'Spatie\\Health\\Facades\\Health',
    ),
  ),
  'spatie/laravel-ignition' => 
  array (
    'providers' => 
    array (
      0 => 'Spatie\\LaravelIgnition\\IgnitionServiceProvider',
    ),
    'aliases' => 
    array (
      'Flare' => 'Spatie\\LaravelIgnition\\Facades\\Flare',
    ),
  ),
  'spatie/laravel-permission' => 
  array (
    'providers' => 
    array (
      0 => 'Spatie\\Permission\\PermissionServiceProvider',
    ),
  ),
  'spatie/laravel-settings' => 
  array (
    'providers' => 
    array (
      0 => 'Spatie\\LaravelSettings\\LaravelSettingsServiceProvider',
    ),
  ),
  'stechstudio/filament-impersonate' => 
  array (
    'providers' => 
    array (
      0 => 'STS\\FilamentImpersonate\\FilamentImpersonateServiceProvider',
    ),
  ),
);